﻿using SimpleInventory.Interfaces;
using SimpleInventory.Models;
using SimpleInventory.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace SimpleInventory.Views
{
    /// <summary>
    /// Interaction logic for FinalizePurchase.xaml
    /// </summary>
    public partial class FinalizePurchase : UserControl
    {
        public FinalizePurchase()
        {
            InitializeComponent();
        }
    }
}
