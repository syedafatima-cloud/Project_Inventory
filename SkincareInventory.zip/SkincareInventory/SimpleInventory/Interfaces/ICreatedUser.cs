﻿using SimpleInventory.Models;

namespace SimpleInventory.Interfaces
{
    interface ICreatedUser
    {
        void CreatedUser(User user);
    }
}
